from flask import Response, Flask, redirect, url_for ,render_template,request
import requests
import json
import cv2
from calendar import c
import tensorflow
import keras
import numpy as np
from configparser import ConfigParser

app = Flask(__name__)

#-------Initializations--------#

# Disable scientific notation for clarity
np.set_printoptions(suppress=True)

cam = cv2.VideoCapture(0)

# Load the model for Detection
model = tensorflow.keras.models.load_model('soil_detector_model.h5')

# Load the model for Detection
# model_classifier = tensorflow.keras.models.load_model('soil_detector_model.h5')


data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

#-------Initializations--------#

#-------Database for Login Authorizations--------#
gol_name ='dy by dx'
gol_pass ='dy by dx'
database={'salman':'password'}
#-------Database for Login Authorizations--------#


#-------Global Variables--------#
text = ""
Soil_Detected = False;
Soil_Detection_Response =""
#-------Global Variables--------#

##------- Weather From Openweather API GLOBAL VARIABLES--------#
API_KEY = "682cb2d33ccb8d04b9820301fc9ec025"
ip_request = requests.get('http://get.geojs.io/v1/ip.json')
# ipAdd = '119.160.3.245'
ipAdd = ip_request.json()['ip']
url_ip = 'https://get.geojs.io/v1/ip/geo/'+ipAdd+'.json'
geo_request = requests.get(url_ip)
geo_data = geo_request.json()
print(geo_data)
current_city=geo_data["city"]
current_country=geo_data["country"]
url = "http://api.openweathermap.org/data/2.5/weather?q={}&appid={}&units=metric"
##------- Weather From Openweather API GLOBAL VARIABLES--------#



# ===================== Detection Model and Frames generator ================#
def gen_frames():  # generate frame by frame from camera
    while True:
        success, img = cam.read()  # read the camera frame
        if not success:
            break
        else:
            img = cv2.resize(img,(224, 224))
            image_array = np.asarray(img)
            normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1
            data[0] = normalized_image_array
            prediction = model.predict(data)
            for i in prediction:
                if i[0] > 0.7:
                    text ="Soil_Detected"
                    global Soil_Detected
                    Soil_Detected = True
                    break;
                elif i[1] > 0.7:
                    text ="Not a Soil P(human)"
                else:
                    text ="something else"
                # print(text)
            img = cv2.resize(img,(500, 500))
            cv2.putText(img,text,(10,30),cv2.FONT_HERSHEY_COMPLEX_SMALL,2,(0,255,0),1)           
            ret, buffer = cv2.imencode('.jpg', img)
            img = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + img + b'\r\n')
# ===================== Detection Model and Frames generator ================#

## ===================== Methods for Soil Detection ================#

def Soil_Detection():
    if Soil_Detected != True:
        global Soil_Detection_Response
        Soil_Detection_Response="Processing"
        return  Soil_Detection_Response
    else:
        Soil_Detection_Response= "Soil Detected"
        return Soil_Detection_Response
            
## ===================== Methods for Soil Detection Ends================#

##------- Weather From Openweather API -----------------#
@app.route('/search_city')
def search_city():
    # city = request.args.get(current_city)  # city name passed as argument
    # print(city)
    # call API and convert response into Python dictionary
    url = f'http://api.openweathermap.org/data/2.5/weather?q={current_city}&APPID={API_KEY}'
    response = requests.get(url).json()
    
    # error like unknown city name, inavalid api key
    if response.get('cod') != 200:
        message = response.get('message', '')
        return f'Error getting temperature for {current_city}. Error message = {message}'
    
    # get current temperature and convert it into Celsius
    current_temperature = response.get('main', {}).get('temp')
    if current_temperature:
        current_temperature_celsius = round(current_temperature - 273.15, 2)
        return current_temperature_celsius
    else:
        return 'Error'
##------- Weather From Openweather API End-----------------#




# Routing Of Application
@app.route('/detection_response')
def detection_response():
     return Response(Soil_Detection())

@app.route('/video_feed')
def video_feed():
    #Video streaming route. Put this in the src attribute of an img tag
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# @app.route('/video_feed_classifier')
# def video_feed_classifier():
#     #Video streaming route. Put this in the src attribute of an img tag
#     return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/')
def home():
    return redirect(url_for('index'))

@app.route('/login',methods=["POST","GET"])
def login():
    name1=request.form['name']
    pwd=request.form['password']
    global gol_name
    gol_name=name1
    global gol_pass
    gol_pass=pwd
    print(gol_name)
    if name1 not in database:
        return render_template('index.html')    
    else:
        if database[name1]!=pwd:
            return render_template('index.html')
        else:
            #return render_template('scan.html')
            return scan()
            print(gol_name)

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/detection_process.html')
def scan():
    data_temp = search_city()
    if gol_name not in database:
        return render_template('index.html')    
    else:
        if database[gol_name]!=gol_pass:
            return render_template('index.html')
        else:
            return render_template('detection_process.html', dataToRender=data_temp,ip=ipAdd,city=current_city, country=current_country)

@app.route('/cover')
def cover():
    data_temp = search_city()
    if gol_name not in database:
        return render_template('index.html')    
    else:
        if database[gol_name]!=gol_pass:
            return render_template('index.html')
        else:
            return render_template('cover.html', dataToRender=data_temp,ip=ipAdd,city=current_city, country=current_country)




if __name__ == '__main__': 
   #app.config['ENVIRONMENT_VAR'] = "FLASK_APP=DEVELOPMENT FLASK PROJECTS/app.py"
    app.run(host="0.0.0.0",debug=True, port=5000)




#Classificaiton Model
# def gen_classification_frames():  # generate frame by frame from camera
#     while True:
#         success, img = cam.read()  # read the camera frame
#         if not success:
#             break
#         else:
#             img = cv2.resize(img,(224, 224))
#             image_array = np.asarray(img)
#             normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1
#             data[0] = normalized_image_array
#             prediction = model.predict(data)
#             for i in prediction:
                # if i[0] > 0.9:
                #     text ="Alluvial_Soil"
                # elif i[1] > 0.6:
                #     text ="Cinder_Soil"
                # elif i[2] > 0.6:
                #     text ="Clay_Soil"
                # elif i[3] > 0.6:
                #     text ="Laterite_Soil"
                # elif i[4] > 0.4:
                #     text ="Peat_Soil"
                # elif i[5] > 0.4:
                #     text ="Yellow_Soil"
            #     else:
            #         text ="something else"
            #     # print(text)
            # img = cv2.resize(img,(500, 500))
            # cv2.putText(img,text,(10,30),cv2.FONT_HERSHEY_COMPLEX_SMALL,2,(0,255,0),1)           
            # ret, buffer = cv2.imencode('.jpg', img)
            # img = buffer.tobytes()
            # yield (b'--frame\r\n'
            #        b'Content-Type: image/jpeg\r\n\r\n' + img + b'\r\n')
