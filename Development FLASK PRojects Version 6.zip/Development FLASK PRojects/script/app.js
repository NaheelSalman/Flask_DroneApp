function activate() {
    window.location.href = "";
  }