from flask import Response, Flask, redirect, url_for ,render_template,request
import requests
import json
import cv2
from configparser import ConfigParser
app = Flask(__name__)


camera = cv2.VideoCapture(-1)

def gen_frames():  # generate frame by frame from camera
    while True:
        # Capture frame-by-frame
        success, frame = camera.read()  # read the camera frame
        if not success:
            break
        else:
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')  # concat frame one by one and show result




# Weather From Openweather API
API_KEY = "682cb2d33ccb8d04b9820301fc9ec025"
ip_request = requests.get('http://get.geojs.io/v1/ip.json')
# ipAdd = '119.160.3.245'
ipAdd = ip_request.json()['ip']
url_ip = 'https://get.geojs.io/v1/ip/geo/'+ipAdd+'.json'
geo_request = requests.get(url_ip)
geo_data = geo_request.json()
print(geo_data)
current_city=geo_data["city"]
current_country=geo_data["country"]
url = "http://api.openweathermap.org/data/2.5/weather?q={}&appid={}&units=metric"

@app.route('/search_city')
def search_city():
    # city = request.args.get(current_city)  # city name passed as argument
    # print(city)
    # call API and convert response into Python dictionary
    url = f'http://api.openweathermap.org/data/2.5/weather?q={current_city}&APPID={API_KEY}'
    response = requests.get(url).json()
    
    # error like unknown city name, inavalid api key
    if response.get('cod') != 200:
        message = response.get('message', '')
        return f'Error getting temperature for {current_city}. Error message = {message}'
    
    # get current temperature and convert it into Celsius
    current_temperature = response.get('main', {}).get('temp')
    if current_temperature:
        current_temperature_celsius = round(current_temperature - 273.15, 2)
        return current_temperature_celsius
    else:
        return 'Error'




# Weather From Openweather API End



@app.route('/video_feed')
def video_feed():
    #Video streaming route. Put this in the src attribute of an img tag
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/')
def home():
    return redirect(url_for('index'))

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/scan')
def scan():
    data_temp = search_city()
    return render_template('scan.html',  dataToRender=data_temp,ip=ipAdd,city=current_city, country=current_country)

@app.route('/cover')
def cover():
    data_temp = search_city()
    return render_template('cover.html', dataToRender=data_temp,ip=ipAdd,city=current_city, country=current_country)




if __name__ == '__main__': 
   #app.config['ENVIRONMENT_VAR'] = "FLASK_APP=DEVELOPMENT FLASK PROJECTS/app.py"
    app.run(host="0.0.0.0",debug=True, port=5000)